**A great addition to a virtual dining table.**

Scanned using physically based process developed by inciprocal Inc. that enables highly photo-realistic reproduction of real-world products in virtual environments.

Zip file includes low-poly OBJ mesh (in meters) with a set of 2k PBR textures compressed with *lossless* JPEG (no chroma sub-sampling).